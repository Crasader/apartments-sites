<?php

/**
 * configFiltersSimpleFilter actions.
 *
 * @package    project
 * @subpackage configFiltersSimpleFilter
 * @author     Fabien Potencier <fabien.potencier@symfony-project.com>
 * @version    SVN: $Id: actions.class.php 2288 2006-10-02 15:22:13Z fabien $
 */
class configFiltersSimpleFilterActions extends sfActions
{
  public function executeIndex()
  {
  }
}
