<?php

class myAppsFrontendModulesAutoloadLibClass
{
  static public function ping()
  {
    return 'pong';
  }
}
