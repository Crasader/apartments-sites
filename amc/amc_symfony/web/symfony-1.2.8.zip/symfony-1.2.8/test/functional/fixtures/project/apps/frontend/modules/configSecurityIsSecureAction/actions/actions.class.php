<?php

/**
 * configSecurityIsSecure actions.
 *
 * @package    project
 * @subpackage configSecurityIsSecure
 * @author     Fabien Potencier <fabien.potencier@symfony-project.com>
 * @version    SVN: $Id: actions.class.php 3625 2007-03-17 11:04:36Z fabien $
 */
class configSecurityIsSecureActionActions extends sfActions
{
  public function executeIndex()
  {
  }
}
